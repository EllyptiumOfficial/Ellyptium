from setuptools import setup

setup(name = "Ellyptium",
    version = "0.5",
    description = "Ellyptium package",
    author = "Esteban Sánchez - IG: @pythonstudent",
    author_email = "fosanzgames@gmail.com",
    license = "AGPL-3.0",
    url = "https://github.com/EllyptiumOfficial/Ellyptium",
    packages=['Ellyptium'],
    classifiers = ["Development Status :: 5 - Alpha",
                   "topics :: Utilities",
                   "License :: AGPL-3.0"]
)