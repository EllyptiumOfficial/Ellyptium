from os import sys
def launch_error(*args):        #DEFINICIÓN DE FUNCIÓN LAUNCH_ERROR()
    try:                        
        raise Exception         #Lanza un error Exception

    except Exception:           #La misma función lo recoge y lanza un mensaje personalizado
        lines = ""
        for a in args:
            lines += a
            lines += "\n"       #Pueden ser tantas lineas como se quieran, siempre separadas por comas
        
        print(lines)            
        sys.exit()              #Termina la ejecución aun siendo una función externa