from .diagonal import diagonal
from .pascal_triangle import pascal_triangle
from .errors import launch_error
